import * as fs from 'fs/promises';
import * as path from 'path';
import { spawn } from 'child_process';
import { PublicKey, Connection } from '@solana/web3.js';
//mport { RpcPoolManager } from '../../utils/rpc/rpc-pool-manager';
//import { extractRentalStatePubkeys, extractFleetPubkeys, extractThreadPubkeys } from './extractPubkeys';

// Funzione batch per fetch account
async function batchFetchAccounts(pubkeys: string[], connection: Connection): Promise<Buffer[]> {
  const chunkSize = 100;
  const buffers: Buffer[] = [];
  for (let i = 0; i < pubkeys.length; i += chunkSize) {
    const chunk = pubkeys.slice(i, i + chunkSize);
    const pubkeyObjs = chunk.map((k) => new PublicKey(k));
    console.log(`[rentalHybridService] Fetching accounts chunk: ${i}-${i + chunk.length - 1} (${chunk.length} pubkeys)`);
    try {
      const accounts = await connection.getMultipleAccountsInfo(pubkeyObjs, 'confirmed');
      buffers.push(...accounts.map(acc => acc?.data ?? Buffer.alloc(0)));
      console.log(`[rentalHybridService] Fetched ${accounts.length} accounts for chunk ${i}-${i + chunk.length - 1}`);
    } catch (err) {
      console.error(`[rentalHybridService] Error fetching accounts chunk ${i}-${i + chunk.length - 1}:`, err);
      throw err;
    }
  }
  return buffers;
}

// Funzione principale minimal
export async function fetchAndDecodeAll(profileId: string, contractPubkeys: string[], rustBinPath: string) {
  console.log('[Hybrid] Inizio fetchAndDecodeAll per profileId:', profileId);
  const { connection, release } = await RpcPoolManager.pickRpcConnection(profileId);

  console.log('[Hybrid] Contract pubkeys:', contractPubkeys);
  const contractBuffers = await batchFetchAccounts(contractPubkeys, connection);
  console.log('[Hybrid] ContractState buffer count:', contractBuffers.length);

  const rentalPubkeys = extractRentalStatePubkeys(contractBuffers);
  const fleetPubkeys = extractFleetPubkeys(contractBuffers);
  console.log('[Hybrid] RentalState pubkeys:', rentalPubkeys);
  console.log('[Hybrid] Fleet pubkeys:', fleetPubkeys);
  const rentalBuffers = rentalPubkeys.length > 0 ? await batchFetchAccounts(rentalPubkeys, connection) : [];
  const fleetBuffers = fleetPubkeys.length > 0 ? await batchFetchAccounts(fleetPubkeys, connection) : [];
  console.log('[Hybrid] RentalState buffer count:', rentalBuffers.length);
  console.log('[Hybrid] Fleet buffer count:', fleetBuffers.length);

  const threadPubkeys = extractThreadPubkeys(rentalBuffers);
  console.log('[Hybrid] Thread pubkeys:', threadPubkeys);
  const threadBuffers = threadPubkeys.length > 0 ? await batchFetchAccounts(threadPubkeys, connection) : [];
  console.log('[Hybrid] Thread buffer count:', threadBuffers.length);

  const allBuffers = [...contractBuffers, ...rentalBuffers, ...fleetBuffers, ...threadBuffers];
  console.log('[Hybrid] Total buffers to decode:', allBuffers.length);

  const rustProcess = spawn(rustBinPath, ['decode', '--json']);
  rustProcess.stdin.write(JSON.stringify(allBuffers.map(b => Array.from(b))));
  rustProcess.stdin.end();

  let output = '';
  for await (const chunk of rustProcess.stdout) {
    output += chunk;
  }
  await new Promise(resolve => rustProcess.on('close', resolve));

  if (!output) {
    console.error('[Hybrid] Nessun output dal binario Rust!');
  } else {
    console.log('[Hybrid] Output Rust ricevuto, lunghezza:', output.length);
  }

  let decoded;
  try {
    decoded = JSON.parse(output);
    console.log('[Hybrid] Decodifica JSON riuscita, oggetti:', Array.isArray(decoded) ? decoded.length : typeof decoded);
  } catch (e) {
    console.error('[Hybrid] Errore parsing JSON output Rust:', e);
    throw e;
  }

  // Applica il limit anche al file salvato, se contractPubkeys.length < decoded.length
  let toSave = decoded;
  if (Array.isArray(decoded) && contractPubkeys.length > 0 && decoded.length > contractPubkeys.length) {
    toSave = decoded.slice(0, contractPubkeys.length);
  }

  const dir = path.join(process.cwd(), 'cache', profileId, 'rented_contracts');
  await fs.mkdir(dir, { recursive: true });
  const file = path.join(dir, 'contracts.json');
  await fs.writeFile(file, JSON.stringify(toSave, null, 2), 'utf8');
  console.log('[Hybrid] Salvato in', file);

  release({ success: true });
  return toSave;
}
