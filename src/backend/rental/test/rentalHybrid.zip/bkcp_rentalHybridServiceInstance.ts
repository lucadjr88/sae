import path from 'path';
const __dirname = new URL('.', import.meta.url).pathname;
//import { fetchAndDecodeAll } from './rentalHybridService';
import { PublicKey } from '@solana/web3.js';

const SRSLY_PROGRAM_ID = process.env.SRSLY_PROGRAM_ID || 'SRSLY1fq9TJqCk1gNSE7VZL2bztvTn9wm4VR8u8jMKT';
const RUST_BIN_PATH = process.env.SRSLY_DECODER_BIN || '../../../dist/backend/decoder/srsly-decoder';

export async function getHybridContracts(profileId: string, limit?: number): Promise<any[]> {
  // 1. Recupera tutti i pubkey dei contratti on-chain
  // (replica la logica di fetchContractsOnChain, ma solo per i pubkey)
  //const { RpcPoolManager } = await import('../../utils/rpc/rpc-pool-manager');
  const bs58 = (await import('bs58')).default;
  const { Connection, PublicKey } = await import('@solana/web3.js');

  const { connection, release } = await RpcPoolManager.pickRpcConnection(profileId);
  const accounts = await connection.getProgramAccounts(new PublicKey(SRSLY_PROGRAM_ID), {
    filters: [{ memcmp: { offset: 0, bytes: bs58.encode(Uint8Array.from([0xbe,0x8a,0x0a,0xdf,0xbd,0x74,0xde,0x73])) } }],
    commitment: 'confirmed',
  });
  release({ success: true });
  let contractPubkeys = accounts.map(({ pubkey }) => pubkey.toBase58());
  if (typeof limit === 'number' && Number.isFinite(limit) && limit > 0) {
    contractPubkeys = contractPubkeys.slice(0, limit);
  }

  // 2. Orchestrazione ibrida
  return fetchAndDecodeAll(profileId, contractPubkeys, RUST_BIN_PATH);
}
